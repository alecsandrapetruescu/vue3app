<template>
  <div>Profile</div>
</template>

<script>
export default {
  name: "Profile"
};
</script>
