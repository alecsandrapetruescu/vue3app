<template>
  <AppLayout>
    <router-view />
  </AppLayout>
</template>

<script>
export default {
  name: "App"
};
</script>
