<template>
  <div>loading</div>
</template>

<script>
export default {
  name: "LoadingComponent"
};
</script>
