<template>
  <div>LandingPage</div>
</template>

<script>
export default {
  name: "LandingPage"
};
</script>
